events.on("ready",function(){$(".completeScorm").isInViewportComplete({container:$(".mr-full"),call:function(){console.log("complete one-page"),scorm.setCompleted()}})});
//# sourceMappingURL=script.js.map
